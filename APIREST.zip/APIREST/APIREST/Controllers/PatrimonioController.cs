﻿using APIREST.Infra;
using APIREST.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIREST.Controllers
{
    [Route("")]
    [Route("Patrimonio")]
    public class PatrimonioController : ApiController
    {
        private static List<Patrimonio> listaPatrimonio = new List<Patrimonio>();

        [Route("ConsultarPatrimonios")]
        [HttpGet]
        public List<Patrimonio> ConsultarPatrimonios()
        {
            using (ApiContext contexto = new ApiContext())
            {
                var listaPatrimonio = contexto.Patrimonios.ToList();
                return listaPatrimonio;
            }
        }
        
        [Route("Patrimonio/ConsultarPatrimonioPorMarcaID")]
        //[HttpGet("{id}")]
        public Patrimonio ConsultarPatrimonioPorMarcaID(int patrimonio)
        {
            using (ApiContext contexto = new ApiContext())
            {
                Patrimonio patrimonios = listaPatrimonio.Where(n => n.MarcaID == patrimonio)
                         .Select(n => n)
                         .FirstOrDefault();

                return patrimonios;
            }
        }
      
        [Route("CadastrarPatrimonio")]
        [HttpPost]
        public string CadastrarPatrimonio(Patrimonio patrimonios)
        {
            using (ApiContext contexto = new ApiContext())
            {
                contexto.Patrimonios.Add(patrimonios);
                contexto.SaveChanges();

                return "Patrimônio cadastrado com sucesso!";
            }
        }

        [Route("AlterarPatrimonio")]
        [HttpPut]
        public string AlterarPatrimoio(Patrimonio patrimonios)
        {
            using (ApiContext contexto = new ApiContext())
            {
                listaPatrimonio.Where(n => n.MarcaID == patrimonios.MarcaID)
                         .Select(s =>
                         {
                             s.MarcaID = patrimonios.MarcaID;
                             s.Descricao = patrimonios.Descricao;
                             s.Nome = patrimonios.Nome;

                             return s;

                         }).ToList();

            return "Patrimonio alterado com sucesso!";
            }
        }


        [Route("ExcluirPatrimonio")]
        [HttpDelete]
        public string ExcluirPatrimonio(int MarcaID)
        {
            using (ApiContext contexto = new ApiContext())
            { 
                Patrimonio patrimonio = listaPatrimonio.Where(n => n.MarcaID == MarcaID)
                                                .Select(n => n)
                                                .First();

            listaPatrimonio.Remove(patrimonio);
            contexto.SaveChanges();

            return "Registro excluído com sucesso!";
            }
        }
    }
}