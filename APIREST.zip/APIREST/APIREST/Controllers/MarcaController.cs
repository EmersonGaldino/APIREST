﻿using APIREST.Infra;
using APIREST.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIREST.Controllers
{

    [Route("api/[controller]")]
    public class MarcaController : ApiController
    {
        private static List<Marca> listaMarca = new List<Marca>();

        [HttpGet]
        [Route("api/Marca/ConsultarMarcas")]
        public List<Marca> ConsultarMarca()
        {
            using (ApiContext contexto = new ApiContext())
            {
                var listaMarca = contexto.Marcas.ToList();
                return listaMarca;
            }
        }

        [HttpGet]
        [Route("api/Marca/ConsultarMarcas/ConsultarMarcaPorID")]
        public Marca ConsultarMarcaporMarcaID(int Marca)
        {
            using (ApiContext contexto = new ApiContext())
            {
                Marca Marcas = listaMarca.Where(n => n.MarcaID == Marca)
                                                .Select(n => n)
                                                .FirstOrDefault();
            
                return Marcas;
            }
        }

        [HttpPost]
        [Route("CadastrarMarca")]
        public string CadastrarMarca(Marca Marcas)
        {
            using (ApiContext contexto = new ApiContext())
            {
                contexto.Marcas.Add(Marcas);
                contexto.SaveChanges();

                return "Marca cadastrada com sucesso!";
            }
        }

        [HttpPut]
        [Route("AlterarMarca/4")]
        public string AlterarMarca(Marca Marcas)
        {
            using (ApiContext contexto = new ApiContext())
            { 
                listaMarca.Where(n => n.MarcaID == Marcas.MarcaID)
                             .Select(s =>
                             {
                                 s.MarcaID = Marcas.MarcaID;
                                 s.Nome = Marcas.Nome;

                                 return s;

                             }).ToList();


                return "Marca alterado com sucesso!";
            }
        }

        [HttpDelete]
        [Route("ExcluirMarca")]
        public string ExcluirPatrimonio(int MarcaID)
        {
            using (ApiContext contexto = new ApiContext())
            { 
                Marca Marcas = listaMarca.Where(n => n.MarcaID == MarcaID)
                                                .Select(n => n)
                                                .First();
                
                listaMarca.Remove(Marcas);
                contexto.SaveChanges();

                return "Registro excluido com sucesso!";
            }
        }
    }
}