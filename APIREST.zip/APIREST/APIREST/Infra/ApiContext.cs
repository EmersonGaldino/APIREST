﻿using APIREST.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace APIREST.Infra
{
    public class ApiContext : DbContext
    {
        public ApiContext() : base("name=api")
        {
        }
        [Key]
        public DbSet<Marca> Marcas { get; set; }
        public DbSet<Patrimonio> Patrimonios { get; set; }
    }
}
    

