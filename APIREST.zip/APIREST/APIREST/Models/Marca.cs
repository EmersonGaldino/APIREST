﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace APIREST.Models
{
    public class Marca
    {
        public string Nome { get; set; }
        [Key]
        public int MarcaID { get; set; }
    }
}