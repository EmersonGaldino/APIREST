﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace APIREST.Models
{
    public class Patrimonio
    {
  
        public string Nome { get; set; }
        [Key]
        public int MarcaID { get; set; }
       
        public string Descricao { get; set; }
       
        public int NumeroTombo { get; set; }

    }
}